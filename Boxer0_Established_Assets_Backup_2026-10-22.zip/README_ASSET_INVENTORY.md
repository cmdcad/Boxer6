# Boxer0 Asset Backup — 2026-10-22

## Status
- Blue Opening Burst V2: approved, 13 frames, 18 FPS, non-looping.
- Blue Advance V3: selected frames 0–12, looping, speed adjustable.
- Orange Bounce V3: candidate, awaiting final approval.
- Blue Punch: frames 185–225 extracted; not isolated or approved.
- Integration ZIP includes burst + advance and SpriteKit helper; not verified in app.
- Sprite size: 512x512 RGBA; root (256,448).
- GitHub registry committed to assets/boxer0-animation-registry, but binary ZIPs not yet pushed.

## Files and SHA-256
- Approved/Boxer0_Blue_Opening_Burst_V2.zip | 1456830 bytes | f09ad8b249c78235ba3242f7bb12a7d016e22249866a31c9d7df53983906f4b0
- Selected/Boxer0_Blue_Advance_V3.zip | 3479309 bytes | d056f9d984dc8b164fd92cc900ac718351a55bfdf9e663ed3924853b1f1f2169
- Integration/Boxer0_Blue_Burst_Advance_Approved.zip | 2572946 bytes | e401b007e3b425d1f4d115e8ce9e6ad72ac32e9a963517c6651caee4d36acfbb
- Candidate/Boxer0_Orange_Bounce_V3.zip | 2133312 bytes | 6c27443bf4d3474ce94c9ea224938f143c0f4ebfd3d4464de5aa3b69c75e2ff3
- Source/Boxer0_Blue_Punch_Source_Frames_185-225.zip | 6410864 bytes | ec70f65562d910fb3401b8abaa92dde07e20755e5c4661dde966eb3d4b58fb46
- Source/cleaned_frames.zip | 1644926 bytes | 7726fcbfe2ad3e825aa0693e7e7fec2800e9ab56c1bc3beeb513c210834dde6a
- Source/frames_514.zip | 3722697 bytes | 4a08c104eb44775d16eea645fc32598280c51d46145b692302a359e5c5e60183
- Source/Edited(2).zip | 636575 bytes | 4af95989c6efe5e702a2a901a72310fcc2e646a2f90015d64f7fbc4f4ffbc62d
- Docs/Boxing_Placeholder_Sprite_Specification.docx | 44672 bytes | 45611f0a15e01a574ea7a21f54f1bb6e54479e3d24f89bf90e77cbcfb100c579
- Code/IdleTestScene.swift | 12459 bytes | 7f047ba061df4df794dcf17815087d83ebb694005119e5dac4029975a168ed35
- Code/ContentView.swift | 7498 bytes | 9d6d8568f4dc59905143ddbe81792f5c4a71ddba69853b7d3d1cfdddde70c2bd
- Originals/StaticBoxers.zip | 143582 bytes | 084cbc764a3f73480e5b94c85fdba84606ef841637227ee25efe457da9c9c4d7
- Originals/Assets.xcassets.zip | 1165559 bytes | c78ddc1ce3f5d7b21d84f70a5456bfebc8d6d6434f4fa73b465a4a4904b862ce
- Originals/boxing_reference.mp4 | 2957016 bytes | 4975290054bcba9585acd0c2ebbac57e08365ab7369d1eaf9e8e47ee42362f80
- Originals/punch_reference.mp4 | 3759346 bytes | 4c00c71936a1247acc315f7f7797199acf63475438515ba10f8d135a3e6554a4
