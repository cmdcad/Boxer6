# Orange Heavy Hit Reaction — motion reference V1

Extracted source-video frames 152–201 for studying Orange recoil and stagger. The reference contains Blue and backgrounds. This is NOT a finished Orange sprite animation. A new matched-style, transparent sequence still needs to be produced and validated against Orange Bounce V3. The visual concept is illustrative only.
