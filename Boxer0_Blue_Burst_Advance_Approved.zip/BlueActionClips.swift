import SpriteKit

/// Put both numbered PNG sets into Assets.xcassets as individual image sets,
/// or adapt the texture loader for your preferred bundle structure.
enum BlueActionClips {
    static func textures(prefix: String, count: Int) -> [SKTexture] {
        (0..<count).map { SKTexture(imageNamed: String(format: "%@_%03d", prefix, $0)) }
    }

    static func openingBurst() -> SKAction {
        .animate(with: textures(prefix: "blue_opening_burst", count: 13),
                 timePerFrame: 1.0 / 24.0, resize: false, restore: false)
    }

    static func advanceCycle() -> SKAction {
        .repeatForever(.animate(with: textures(prefix: "blue_advance", count: 13),
                                timePerFrame: 1.0 / 24.0, resize: false, restore: false))
    }

    /// Run on the existing blue SKSpriteNode, keeping its anchor at (0.5, 0.125).
    /// Movement in world coordinates should be handled by the scene separately.
    static func playOpeningThenAdvance(on boxer: SKSpriteNode) {
        boxer.removeAction(forKey: "blueAction")
        boxer.run(.sequence([openingBurst(), advanceCycle()]), withKey: "blueAction")
    }
}
