Approved Blue Opening Burst V2 (13 frames) + selected Blue Advance V3 (0–12).
Both 512x512 RGBA; root (256,448) top-left, SpriteKit anchor (0.5,0.125).
Blue Opening Burst is non-looping. Advance is selected for repeat playback, but its wraparound seam has not been corrected.
Source video frame 54 is absent. Review transition_comparison.jpg and test the handoff in-game.
BlueActionClips.swift is a standalone integration helper, not a modification of IdleTestScene.swift.
