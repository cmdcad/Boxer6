Orange recovery alignment kit V1

Contains exact Orange Bounce V3 anchor PNGs. Recovery frames must be created to converge on target_guard.png, with feet/scale/guard matching. When recovery finishes, continue Bounce V3 at bounce_next.png. No recovery sprites are claimed complete in this kit.
